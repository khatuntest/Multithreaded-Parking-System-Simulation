
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        System.out.println("Enter the number of processes: ");
        int n = cin.nextInt();
        List<Processes> process = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            System.out.println("Enter Arrival Time, Burst Time, Priority for Process " + (i + 1));
            int arrivalTime = cin.nextInt();
            int burstTime = cin.nextInt();
            int priority = cin.nextInt();
            Processes p = new Processes(i + 1, arrivalTime, burstTime, priority);
            process.add(p);
        }
        Priority p=new Priority(process);
        p.Calculation();
        p.display();
        cin.close();
    }
}