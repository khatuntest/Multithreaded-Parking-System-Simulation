import java.util.*;
class Priority {
    private Deque<Processes> processes = new ArrayDeque<>();
    private Deque<Processes> schedule = new ArrayDeque<>();
    private int currentTime = 0, totalWaiting = 0, totalTurnaround = 0;

    Priority(List<Processes> p) {
        p.sort(Comparator.comparingInt(p1 -> p1.arrive));
        processes.addAll(p);
    }
    public void Calculation() {
        Queue<Processes> ready = new PriorityQueue<>(
                Comparator.comparingInt((Processes p) -> p.priority)
                        .thenComparingInt(p -> p.arrive)
        );
        while (!processes.isEmpty() || !ready.isEmpty()) {
            // Move processes that have arrived to the ready queue
            while (!processes.isEmpty() && processes.peek().arrive <= currentTime) {
                ready.offer(processes.poll());
            }
            if (ready.isEmpty()) {
                currentTime++;
                continue;
            }
            Processes currentProcess = ready.poll();
            while (currentProcess.remainingBurst > 0) {  // Process execution loop
                currentTime++;
                currentProcess.remainingBurst--;
                // Check for newly arrived higher priority processes
                while (!processes.isEmpty() && processes.peek().arrive <= currentTime) {
                    Processes newProcess = processes.poll();
                    ready.offer(newProcess);
                    // Interrupt current process if a higher priority process arrives
                    if (newProcess.priority < currentProcess.priority) {
                        ready.offer(currentProcess); // Re-add current process to the ready queue
                        currentProcess = null;      // Stop the current process
                        break;
                    }
                }
                if (currentProcess == null) {
                    break; // Stop execution of the current process if interrupted
                }
            }
            // If the process finishes
            if (currentProcess != null && currentProcess.remainingBurst == 0) {
                int turnaroundTime = currentTime - currentProcess.arrive;
                int waitingTime = turnaroundTime - currentProcess.burst;
                currentProcess.turnAround = turnaroundTime;
                currentProcess.waitTime = waitingTime;
                schedule.add(currentProcess); // Add to completed processes
                totalTurnaround += turnaroundTime;
                totalWaiting += waitingTime;
            }
        }
    }
    public void display() {
        System.out.println("Execution Schedule:");
        for (Processes p : schedule) {
            System.out.println("ID: " + p.id + ", Arrival: " + p.arrive +
                    ", Burst: " + p.burst + ", Priority: " + p.priority +
                    ", Waiting: " + p.waitTime + ", Turnaround: " + p.turnAround);
        }
        System.out.println("Total Waiting Time: " + totalWaiting);
        System.out.println("Total Turnaround Time: " + totalTurnaround);
    }
}
