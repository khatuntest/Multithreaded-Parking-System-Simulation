import java.util.ArrayList;
import java.util.List;

class Process {
    String name;
    int arrivalTime, burstTime, priority, remainingTime, quantum, inProgress;
    double fcaiFactor;
    List<Integer> quantumHistory;

    public Process(String name, int arrivalTime, int burstTime, int priority, int quantum) {
        this.name = name;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.priority = priority;
        this.remainingTime = burstTime;
        this.quantum = quantum;
        quantumHistory = new ArrayList<>();
        quantumHistory.add(quantum);
        inProgress = 0;
    }

    public void updateFcaiFactor(double v1, double v2) {
        fcaiFactor = (10 - priority) + (arrivalTime / v1) + (remainingTime / v2);
    }
}