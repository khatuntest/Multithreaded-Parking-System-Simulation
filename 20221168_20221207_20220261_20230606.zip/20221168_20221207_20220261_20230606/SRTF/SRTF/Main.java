import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the number of processes
        System.out.print("Enter the number of processes: ");
        int numProcesses = scanner.nextInt();

        // Input the context switching time
        System.out.print("Enter the context switching time (in time units): ");
        int contextSwitchTime = scanner.nextInt();

        int maxWaitTime = 5;

        // Input process details
        List<Process> processes = new ArrayList<>();
        for (int i = 0; i < numProcesses; i++) {
            System.out.println("Enter details for Process " + (i + 1) + ":");
            System.out.print("Arrival Time: ");
            int arrivalTime = scanner.nextInt();
            System.out.print("Burst Time: ");
            int burstTime = scanner.nextInt();

            // Assign names automatically (P1, P2, ...)
            String name = "P" + (i + 1);
            processes.add(new Process(name, arrivalTime, burstTime));
        }

        // Create an instance of SRTF and schedule the processes
        SRTF srtfScheduler = new SRTF();
        srtfScheduler.scheduleProcesses(processes, contextSwitchTime, maxWaitTime);

        scanner.close();
    }
}
