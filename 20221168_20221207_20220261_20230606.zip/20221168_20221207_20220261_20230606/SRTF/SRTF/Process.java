class Process {
    String name; // Process Name
    int arrivalTime; // Arrival Time
    int burstTime; // Original Burst Time
    int remainingTime; // Remaining Burst Time
    int waitingTime; // Waiting Time
    int turnaroundTime; // Turnaround Time
    int completionTime; // Completion Time
    boolean isCompleted; // Completion Status
    int waitedTime; // Tracks how long the process has been waiting

    public Process(String name, int arrivalTime, int burstTime) {
        this.name = name;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.remainingTime = burstTime;
        this.waitingTime = 0;
        this.turnaroundTime = 0;
        this.completionTime = 0;
        this.isCompleted = false;
        this.waitedTime = 0;
    }
}