import java.util.*;

public class SRTF
{

    public void scheduleProcesses(List<Process> processes, int contextSwitchTime, int maxWaitTime) {
        int currentTime = 0;
        int completedProcesses = 0;
        int n = processes.size();
        List<String> executionOrder = new ArrayList<>();
        Process currentlyExecutingProcess = null;

        while (completedProcesses < n) {
            Process currentProcess = null;

            // SRTF logic with starvation prevention
            for (Process p : processes) {
                if (!p.isCompleted && p.arrivalTime <= currentTime) {
                    // Check if the process has waited too long
                    if (p.waitedTime >= maxWaitTime) {
                        // Temporarily prioritize this process for selection
                        currentProcess = p;
                        break;
                    }

                    // Regular SRTF: Choose the process with the shortest remaining time
                    if (currentProcess == null || p.remainingTime < currentProcess.remainingTime) {
                        currentProcess = p;
                    }
                }
            }

            if (currentProcess != null) {
                // Log the execution of the process at this moment
                if (currentlyExecutingProcess != currentProcess) {
                    // Log context switch only if the next process is different
                    if (currentlyExecutingProcess != null) {
                        System.out.println("Time: " + currentTime + " -> Context switch: " + currentlyExecutingProcess.name + " -> " + currentProcess.name);
                        currentTime += contextSwitchTime;
                    } else {
                        System.out.println("Time: " + currentTime + " -> Starting execution of " + currentProcess.name);
                    }
                }

                // Execute the process for 1 unit of time
                executionOrder.add(currentProcess.name);
                currentProcess.remainingTime--;
                currentTime++;

                // Print the time at which the process was executed
                System.out.println("Time: " + currentTime + " -> Executed: " + currentProcess.name);

                // Reset waited time for the current process
                currentProcess.waitedTime = 0;

                // If the process is completed
                if (currentProcess.remainingTime == 0) {
                    currentProcess.isCompleted = true;
                    currentProcess.completionTime = currentTime;
                    currentProcess.turnaroundTime = currentProcess.completionTime - currentProcess.arrivalTime;
                    currentProcess.waitingTime = currentProcess.turnaroundTime - currentProcess.burstTime;
                    completedProcesses++;

                    // Log when the process completes
                    System.out.println("Time: " + currentTime + " -> " + currentProcess.name + " completed. " +
                            "Completion Time: " + currentProcess.completionTime +
                            ", Turnaround Time: " + currentProcess.turnaroundTime +
                            ", Waiting Time: " + currentProcess.waitingTime);
                }

                // Update the currently executing process
                currentlyExecutingProcess = currentProcess;
            } else {
                // If no process is ready, advance the current time
                System.out.println("Time: " + currentTime + " -> No process is ready, advancing time.");
                currentTime++;
            }

            // Increment waiting time for all processes in the ready queue
            for (Process p : processes) {
                if (!p.isCompleted && p.arrivalTime <= currentTime) {
                    p.waitedTime++;
                }
            }
        }

        // Print the results
        printExecutionOrder(executionOrder);
        printTable(processes);

        // Calculate and print average waiting and turnaround times
        double totalTurnaroundTime = 0, totalWaitingTime = 0;
        for (Process p : processes) {
            totalTurnaroundTime += p.turnaroundTime;
            totalWaitingTime += p.waitingTime;
        }
        System.out.printf("\nAverage Turnaround Time: %.2f\n", totalTurnaroundTime / n);
        System.out.printf("Average Waiting Time: %.2f\n", totalWaitingTime / n);
    }

    private void printExecutionOrder(List<String> executionOrder) {
        System.out.println("\nProcesses Execution Order:");
        for (String processName : executionOrder) {
            System.out.print(processName + " -> ");
        }
        System.out.println("End");
    }

    private void printTable(List<Process> processes) {
        processes.sort(Comparator.comparingInt(p -> p.arrivalTime));

        // Print header
        System.out.printf("\n+-----------+--------------+------------+----------------+----------------+----------------+\n");
        System.out.printf("| Process   | Arrival Time | Burst Time | Completion Time| Turnaround Time| Waiting Time   |\n");
        System.out.printf("+-----------+--------------+------------+----------------+----------------+----------------+\n");

        // Print process details in tabular format
        for (Process p : processes) {
            System.out.printf("| %-9s | %-12d | %-10d | %-14d | %-14d | %-14d |\n",
                    p.name, p.arrivalTime, p.burstTime, p.completionTime, p.turnaroundTime, p.waitingTime);
        }

        // Print footer
        System.out.printf("+-----------+--------------+------------+----------------+----------------+----------------+\n");
    }
}
