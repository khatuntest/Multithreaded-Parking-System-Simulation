public class Processes{
    int id,arrive,burst,priority,waitTime , turnAround , remainingBurst;
    public Processes(int id , int arr, int bur , int p){
        this.id=id;
        this.arrive = arr;
        this.burst = bur;
        this.remainingBurst = bur;
        this.priority = p;
    }
    
}
